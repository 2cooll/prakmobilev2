import 'package:supabase_flutter/supabase_flutter.dart';

class AppSupabase {
  static late final SupabaseClient client;

  static Future<void> init() async {
    await Supabase.initialize(
      url: 'https://fhsmmcuhwujwsgidvgbi.supabase.co',
      anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZoc21tY3Vod3Vqd3NnaWR2Z2JpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMyODc5ODMsImV4cCI6MjA3ODg2Mzk4M30.JTxG6jeK4VfNRVbiracfx_JJz1xVBLQv5E5GtBp4MS4',
    );
    client = Supabase.instance.client;
  }
}
